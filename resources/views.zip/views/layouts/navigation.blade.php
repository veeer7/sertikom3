<nav x-data="{ open: false }" class="sticky top-0 z-50 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800/50 backdrop-blur-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex items-center gap-8">
                <!-- Logo -->
                <a href="{{ route('dashboard') }}" class="flex items-center gap-3 group">
                    <div class="p-2.5 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl border border-cyan-500/30 group-hover:border-cyan-500/60 group-hover:shadow-lg group-hover:shadow-cyan-500/20 transition-all duration-300">
                        <x-application-logo class="block h-6 w-auto fill-current text-cyan-400" />
                    </div>
                    <span class="text-xl font-bold text-slate-100 hidden sm:inline bg-clip-text">Dashboard</span>
                </a>

                <!-- Main Navigation -->
                <div class="hidden sm:flex items-center gap-1">
                    <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')" 
                        class="px-4 py-2 rounded-lg text-slate-400 hover:text-cyan-300 transition-all relative group {{ request()->routeIs('dashboard') ? 'text-cyan-400' : '' }}">
                        Dashboard
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 group-hover:w-full transition-all duration-300 {{ request()->routeIs('dashboard') ? 'w-full' : '' }}"></span>
                    </x-nav-link>

                    <x-nav-link :href="route('tahun-ajar.index')" :active="request()->routeIs('tahun-ajar.*')"
                        class="px-4 py-2 rounded-lg text-slate-400 hover:text-emerald-300 transition-all relative group {{ request()->routeIs('tahun-ajar.*') ? 'text-emerald-400' : '' }}">
                        Tahun Ajar
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-emerald-500 to-teal-500 group-hover:w-full transition-all duration-300 {{ request()->routeIs('tahun-ajar.*') ? 'w-full' : '' }}"></span>
                    </x-nav-link>

                    <x-nav-link :href="route('jurusan.index')" :active="request()->routeIs('jurusan.*')"
                        class="px-4 py-2 rounded-lg text-slate-400 hover:text-purple-300 transition-all relative group {{ request()->routeIs('jurusan.*') ? 'text-purple-400' : '' }}">
                        Jurusan
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-pink-500 group-hover:w-full transition-all duration-300 {{ request()->routeIs('jurusan.*') ? 'w-full' : '' }}"></span>
                    </x-nav-link>

                    <x-nav-link :href="route('kelas.index')" :active="request()->routeIs('kelas.*')"
                        class="px-4 py-2 rounded-lg text-slate-400 hover:text-amber-300 transition-all relative group {{ request()->routeIs('kelas.*') ? 'text-amber-400' : '' }}">
                        Kelas
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-amber-500 to-orange-500 group-hover:w-full transition-all duration-300 {{ request()->routeIs('kelas.*') ? 'w-full' : '' }}"></span>
                    </x-nav-link>

                    <x-nav-link :href="route('siswa.index')" :active="request()->routeIs('siswa.*')"
                        class="px-4 py-2 rounded-lg text-slate-400 hover:text-rose-300 transition-all relative group {{ request()->routeIs('siswa.*') ? 'text-rose-400' : '' }}">
                        Siswa
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-rose-500 to-red-500 group-hover:w-full transition-all duration-300 {{ request()->routeIs('siswa.*') ? 'w-full' : '' }}"></span>
                    </x-nav-link>

                    <x-nav-link :href="route('user-management.index')" :active="request()->routeIs('user-management.*')"
                        class="px-4 py-2 rounded-lg text-slate-400 hover:text-indigo-300 transition-all relative group {{ request()->routeIs('user-management.*') ? 'text-indigo-400' : '' }}">
                        User Management
                        <span class="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-indigo-500 to-violet-500 group-hover:w-full transition-all duration-300 {{ request()->routeIs('user-management.*') ? 'w-full' : '' }}"></span>
                    </x-nav-link>
                </div>
            </div>

            <!-- User Menu -->
            <div class="flex items-center gap-4">
                <div class="hidden sm:block">
                    <x-dropdown align="right" width="48">
                        <x-slot name="trigger">
                            <button class="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-800/50 hover:bg-slate-700/50 transition-all border border-slate-700 hover:border-cyan-500/50 group">
                                <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-500 flex items-center justify-center text-xs font-bold text-white">
                                    {{ substr(Auth::user()->name, 0, 1) }}
                                </div>
                                <span class="text-sm text-slate-300 group-hover:text-cyan-300 transition-colors">{{ Auth::user()->name }}</span>
                            </button>
                        </x-slot>

                        <x-slot name="content">
                            <x-dropdown-link :href="route('profile.edit')" class="text-slate-300 hover:text-cyan-400 hover:bg-slate-800/50">
                                Profile
                            </x-dropdown-link>

                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <x-dropdown-link :href="route('logout')"
                                    onclick="event.preventDefault(); this.closest('form').submit();"
                                    class="text-slate-300 hover:text-rose-400 hover:bg-slate-800/50">
                                    Log Out
                                </x-dropdown-link>
                            </form>
                        </x-slot>
                    </x-dropdown>
                </div>

                <!-- Mobile menu button -->
                <div class="sm:hidden">
                    <button @click="open = ! open" class="inline-flex items-center justify-center p-2 rounded-xl text-slate-400 hover:text-cyan-300 hover:bg-slate-800/50 transition-all border border-transparent hover:border-slate-700">
                        <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                            <path :class="{'hidden': open, 'inline-flex': ! open }" class="inline-flex" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                            <path :class="{'hidden': ! open, 'inline-flex': open }" class="hidden" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Mobile Navigation -->
    <div :class="{'block': open, 'hidden': ! open }" class="hidden sm:hidden bg-slate-900/95 border-t border-slate-800/50">
        <div class="pt-2 pb-3 space-y-1 px-2">
            <x-responsive-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')"
                class="text-slate-300 hover:text-cyan-300 hover:bg-slate-800/50 rounded-lg {{ request()->routeIs('dashboard') ? 'bg-slate-800/50 text-cyan-400' : '' }}">
                Dashboard
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('tahun-ajar.index')" :active="request()->routeIs('tahun-ajar.*')"
                class="text-slate-300 hover:text-emerald-300 hover:bg-slate-800/50 rounded-lg {{ request()->routeIs('tahun-ajar.*') ? 'bg-slate-800/50 text-emerald-400' : '' }}">
                Tahun Ajar
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('jurusan.index')" :active="request()->routeIs('jurusan.*')"
                class="text-slate-300 hover:text-purple-300 hover:bg-slate-800/50 rounded-lg {{ request()->routeIs('jurusan.*') ? 'bg-slate-800/50 text-purple-400' : '' }}">
                Jurusan
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('kelas.index')" :active="request()->routeIs('kelas.*')"
                class="text-slate-300 hover:text-amber-300 hover:bg-slate-800/50 rounded-lg {{ request()->routeIs('kelas.*') ? 'bg-slate-800/50 text-amber-400' : '' }}">
                Kelas
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('siswa.index')" :active="request()->routeIs('siswa.*')"
                class="text-slate-300 hover:text-rose-300 hover:bg-slate-800/50 rounded-lg {{ request()->routeIs('siswa.*') ? 'bg-slate-800/50 text-rose-400' : '' }}">
                Siswa
            </x-responsive-nav-link>

            <x-responsive-nav-link :href="route('user-management.index')" :active="request()->routeIs('user-management.*')"
                class="text-slate-300 hover:text-indigo-300 hover:bg-slate-800/50 rounded-lg {{ request()->routeIs('user-management.*') ? 'bg-slate-800/50 text-indigo-400' : '' }}">
                User Management
            </x-responsive-nav-link>
        </div>

        <div class="border-t border-slate-800/50 pt-4 pb-3">
            <div class="px-4 py-2">
                <div class="text-base font-semibold text-slate-100">{{ Auth::user()->name }}</div>
                <div class="text-sm text-slate-400">{{ Auth::user()->email }}</div>
            </div>

            <div class="mt-3 space-y-1">
                <x-responsive-nav-link :href="route('profile.edit')" class="text-slate-300 hover:text-cyan-400 hover:bg-slate-800/50">
                    Profile
                </x-responsive-nav-link>

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <x-responsive-nav-link :href="route('logout')"
                        onclick="event.preventDefault(); this.closest('form').submit();"
                        class="text-slate-300 hover:text-rose-400 hover:bg-slate-800/50">
                        Log Out
                    </x-responsive-nav-link>
                </form>
            </div>
        </div>
    </div>
</nav>
