<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <!-- Premium dark mode with accent colors -->
    <body class="font-sans antialiased dark bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100 min-h-screen">
        <div class="min-h-screen">
            @include('layouts.navigation')

            @isset($header)
                <header class="bg-gradient-to-r from-slate-900/50 via-slate-900/30 to-slate-900/50 border-b border-slate-800/50 backdrop-blur-sm sticky top-16 z-40">
                    <div class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
                        {{ $header }}
                    </div>
                </header>
            @endisset

            <main class="py-12">
                {{ $slot }}
            </main>
        </div>
    </body>
</html>
