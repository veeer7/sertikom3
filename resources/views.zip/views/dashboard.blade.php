<x-app-layout>
    <x-slot name="header">
        <div class="flex items-end justify-between">
            <div>
                <h2 class="text-4xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">Dashboard</h2>
                <p class="text-slate-400 text-sm mt-2">Selamat datang kembali, <span class="text-cyan-400 font-semibold">{{ Auth::user()->name }}</span></p>
            </div>
            <div class="text-right">
                <p class="text-slate-500 text-xs">{{ now()->format('l, d M Y') }}</p>
            </div>
        </div>
    </x-slot>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Stats Grid with accent colors -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <!-- Tahun Ajar Card -->
            <div class="group bg-gradient-to-br from-slate-900 to-slate-800/50 rounded-2xl border border-slate-800 hover:border-cyan-500/50 p-6 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/10 overflow-hidden relative">
                <div class="absolute inset-0 bg-gradient-to-r from-cyan-500/0 via-cyan-500/0 to-cyan-500/0 group-hover:from-cyan-500/5 group-hover:via-cyan-500/10 group-hover:to-cyan-500/5 transition-all duration-300"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="text-slate-400 text-xs font-semibold uppercase tracking-widest">Tahun Ajar Aktif</p>
                        <h3 class="text-3xl font-bold text-slate-100 mt-3">{{ $tahunAjarAktif->kode_tahun_ajar ?? '-' }}</h3>
                    </div>
                    <div class="p-3 bg-gradient-to-br from-cyan-500/20 to-blue-500/20 rounded-xl border border-cyan-500/30 group-hover:border-cyan-500/60 group-hover:shadow-lg group-hover:shadow-cyan-500/20 transition-all duration-300">
                        <svg class="w-6 h-6 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Jurusan Card -->
            <div class="group bg-gradient-to-br from-slate-900 to-slate-800/50 rounded-2xl border border-slate-800 hover:border-emerald-500/50 p-6 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-500/10 overflow-hidden relative">
                <div class="absolute inset-0 bg-gradient-to-r from-emerald-500/0 via-emerald-500/0 to-emerald-500/0 group-hover:from-emerald-500/5 group-hover:via-emerald-500/10 group-hover:to-emerald-500/5 transition-all duration-300"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="text-slate-400 text-xs font-semibold uppercase tracking-widest">Jurusan Tersedia</p>
                        <h3 class="text-3xl font-bold text-slate-100 mt-3">{{ $totalJurusan }}</h3>
                    </div>
                    <div class="p-3 bg-gradient-to-br from-emerald-500/20 to-teal-500/20 rounded-xl border border-emerald-500/30 group-hover:border-emerald-500/60 group-hover:shadow-lg group-hover:shadow-emerald-500/20 transition-all duration-300">
                        <svg class="w-6 h-6 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C6.5 6.253 2 10.998 2 17s4.5 10.747 10 10.747c5.5 0 10-4.998 10-10.747S17.5 6.253 12 6.253z" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Kelas Card -->
            <div class="group bg-gradient-to-br from-slate-900 to-slate-800/50 rounded-2xl border border-slate-800 hover:border-purple-500/50 p-6 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/10 overflow-hidden relative">
                <div class="absolute inset-0 bg-gradient-to-r from-purple-500/0 via-purple-500/0 to-purple-500/0 group-hover:from-purple-500/5 group-hover:via-purple-500/10 group-hover:to-purple-500/5 transition-all duration-300"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="text-slate-400 text-xs font-semibold uppercase tracking-widest">Kelas Terdaftar</p>
                        <h3 class="text-3xl font-bold text-slate-100 mt-3">{{ $totalKelas }}</h3>
                    </div>
                    <div class="p-3 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl border border-purple-500/30 group-hover:border-purple-500/60 group-hover:shadow-lg group-hover:shadow-purple-500/20 transition-all duration-300">
                        <svg class="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                        </svg>
                    </div>
                </div>
            </div>

            <!-- Siswa Card -->
            <div class="group bg-gradient-to-br from-slate-900 to-slate-800/50 rounded-2xl border border-slate-800 hover:border-rose-500/50 p-6 transition-all duration-300 hover:shadow-xl hover:shadow-rose-500/10 overflow-hidden relative">
                <div class="absolute inset-0 bg-gradient-to-r from-rose-500/0 via-rose-500/0 to-rose-500/0 group-hover:from-rose-500/5 group-hover:via-rose-500/10 group-hover:to-rose-500/5 transition-all duration-300"></div>
                <div class="relative flex items-center justify-between">
                    <div>
                        <p class="text-slate-400 text-xs font-semibold uppercase tracking-widest">Total Siswa</p>
                        <h3 class="text-3xl font-bold text-slate-100 mt-3">{{ $totalSiswa }}</h3>
                    </div>
                    <div class="p-3 bg-gradient-to-br from-rose-500/20 to-red-500/20 rounded-xl border border-rose-500/30 group-hover:border-rose-500/60 group-hover:shadow-lg group-hover:shadow-rose-500/20 transition-all duration-300">
                        <svg class="w-6 h-6 text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.856-1.487M15 10a3 3 0 11-6 0 3 3 0 016 0zM4.318 20H3c-1.1 0-2-1.1-2-2.469V4.469C1 3.369 1.899 2.5 3.217 2.5h15.566c1.318 0 2.217 0.869 2.217 1.969v13.062c0 1.369-.9 2.469-2.217 2.469h-15.405" />
                        </svg>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Students Table with premium styling -->
        <div class="bg-gradient-to-br from-slate-900/50 to-slate-800/50 rounded-2xl border border-slate-800 overflow-hidden backdrop-blur-sm">
            <div class="px-6 py-6 border-b border-slate-800/50 bg-gradient-to-r from-slate-900/50 to-transparent">
                <div class="flex items-center justify-between">
                    <div>
                        <h3 class="text-xl font-bold text-slate-100">Siswa Terbaru</h3>
                        <p class="text-slate-400 text-sm mt-1">10 siswa terbaru yang terdaftar di sistem</p>
                    </div>
                    <div class="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-slate-800/50 rounded-lg border border-slate-700">
                        <div class="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></div>
                        <span class="text-xs text-slate-400">Live</span>
                    </div>
                </div>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="bg-slate-800/30 border-b border-slate-800">
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-300 uppercase tracking-wider">Nama</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-300 uppercase tracking-wider">NISN</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-300 uppercase tracking-wider">Kelas</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-300 uppercase tracking-wider">Jurusan</th>
                            <th class="px-6 py-4 text-left text-xs font-bold text-slate-300 uppercase tracking-wider">Tahun Ajar</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/50">
                        @foreach ($siswas as $siswa)
                        <tr class="hover:bg-slate-800/30 transition-colors duration-200 group">
                            <td class="px-6 py-4 text-sm text-slate-100 font-semibold group-hover:text-cyan-300 transition-colors">{{ $siswa->nama_lengkap }}</td>
                            <td class="px-6 py-4 text-sm text-slate-400 font-mono text-xs">{{ $siswa->nisn }}</td>
                            <td class="px-6 py-4 text-sm">
                                <span class="px-3 py-1.5 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-300 text-xs font-medium hover:border-cyan-500/50 transition-colors">
                                    {{ $siswa->kelas->nama_kelas ?? '-' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm">
                                <span class="px-3 py-1.5 rounded-lg bg-slate-800/50 border border-slate-700 text-slate-300 text-xs font-medium hover:border-emerald-500/50 transition-colors">
                                    {{ $siswa->jurusan->nama_jurusan ?? '-' }}
                                </span>
                            </td>
                            <td class="px-6 py-4 text-sm text-slate-400">{{ $siswa->tahunAjar->kode_tahun_ajar ?? '-' }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-app-layout>
